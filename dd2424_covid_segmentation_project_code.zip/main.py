# From our files
from unet import unet
from augmentations import *
from plot_stuff import *

# Required libraries
from sklearn.model_selection import train_test_split as split
import numpy
import pandas
from tensorflow import keras
from keras.layers import *
from keras.models import *

# -----------------------Parameters--------------------
TEST_SIZE = 0.1
EPOCHS = 5
STEPS_PER_EPOCH = 64
IMG_SIZE = 128
N_IMGS = 20

# -----------------------Load data---------------------
metadata = pandas.read_csv('../input/covid19-ct-scans/metadata.csv')
metadata.head()

# View some samples
view_slices(metadata, [5, 8], "slices_1.png")
view_masks(metadata, 0, "masks.png")

# -----------------------Data augmentation---------------
imgs = metadata['ct_scan']
masks = metadata['infection_mask']

# Experiments 1
scans, masks = load_slices(IMG_SIZE, imgs, masks, N_IMGS)
# Experiments 2
scans, masks = load_sideways(IMG_SIZE, imgs, masks, N_IMGS)

scans = numpy.array(scans)
masks = numpy.array(masks)


# ---------------------------Splits---------------------------
scan_train, scan_test, mask_train, mask_test = split(
    scans, masks, test_size=TEST_SIZE)

# For experiments 3 (use load_slices + below): augment the training set
scan_train, mask_train = aug_many(
    scan_train, mask_train, rotate=False, flip=False, zoom=True)

print("\nTrain set size: {}\nTest set size: {}".format(
    str(scan_train.shape[0]), str(scan_test.shape[0])))

# --------------------------Create, compile and train U-net-----------
model = unet()
model.compile(loss="binary_crossentropy",
              optimizer="adam", metrics=["accuracy"])
# model.summary()

print("\nAaaand here we go with training the model...")
history = model.fit(scan_train, mask_train, epochs=EPOCHS,
                    validation_data=(scan_test, mask_test))

# steps_per_epoch=STEPS_PER_EPOCH
print("\nModel finished training")

# -------------------------Save the results (taken from: https://stackoverflow.com/questions/41061457/keras-how-to-save-the-training-history-attribute-of-the-history-object)

hist_df = pandas.DataFrame(history.history)
hist_csv_file = 'history.csv'
with open(hist_csv_file, mode='w') as f:
    hist_df.to_csv(f)

# ----------------------Segment new lungs with the trained U-net and plot them-----------------------
segmented = model.predict(scan_test)
n_plots = 50
plot_many_segmented(n_plots, scan_test, mask_test, segmented)
