import nibabel
import cv2
import numpy
import random
from tensorflow.keras.preprocessing import image
from plot_stuff import view_data


def unpack(folder):
    ct_scan = nibabel.load(folder)
    imgs = numpy.rot90(numpy.array(ct_scan.get_fdata()))
    return(imgs)


def flip_axis(x, axis):
    x = numpy.asarray(x).swapaxes(axis, 0)
    x = x[::-1, ...]
    x = x.swapaxes(0, axis)
    return x


def aug_many(img_train, mask_train, rotate=True, flip=True, zoom=True):
    n_train_samples = len(img_train)

    img_train_2 = img_train.copy()
    img_train_3 = img_train.copy()
    mask_train_2 = mask_train.copy()
    mask_train_3 = mask_train.copy()

    aug_img_2, aug_mask_2 = aug_one(
        img_train_2, mask_train_2, rotate, flip, zoom)
    aug_img_3, aug_mask_3 = aug_one(
        img_train_3, mask_train_3, rotate, flip, zoom)

    view_idxs = [1, 2, 3, 4]
    view_data(view_idxs, img_train,
              mask_train, "unaugmented.png")

    view_data(view_idxs, aug_img_2, aug_mask_2, "augmented.png")

    aug_img = numpy.concatenate([img_train, img_train_2, img_train_3])
    aug_mask = numpy.concatenate([mask_train, mask_train_2, mask_train_3])

    return aug_img, aug_mask


def aug_one(img_train, mask_train, rotate, flip, zoom):

    n_train_samples = len(img_train)

    if flip:
        rnd_idxs = random.sample(
            range(n_train_samples), int(n_train_samples/2))
        for idx in rnd_idxs:
            img_train[idx] = flip_axis(img_train[idx], 1)
            mask_train[idx] = flip_axis(mask_train[idx], 1)

    if rotate:
        rnd_idxs = random.sample(
            range(n_train_samples), int(n_train_samples/2))

        rotation = 80
        for idx in rnd_idxs:
            img_train[idx] = image.random_rotation(img_train[idx], rotation)
            mask_train[idx] = image.random_rotation(mask_train[idx], rotation)

    if zoom:
        rnd_idxs = random.sample(
            range(n_train_samples), int(n_train_samples/2))

        zoom_range = (0.5, 0.5)
        for idx in rnd_idxs:
            img_train[idx] = image.random_zoom(
                img_train[idx], zoom_range, fill_mode='nearest')
            mask_train[idx] = image.random_zoom(
                mask_train[idx], zoom_range, fill_mode='nearest')
    return img_train, mask_train


def load_sideways(size, imgs, masks, n_images):
    print("\nStarting augmentation...")
    img_array = []
    mask_array = []
    new_dim = (size, size)
    for i in range(n_images, 20):
        img = unpack(imgs[i])
        mask = unpack(masks[i])
        dim = img.shape[0]
        for j in range(dim):
            new_img = cv2.resize(
                img[j], new_dim, interpolation=cv2.INTER_AREA).astype('uint8')
            new_mask = cv2.resize(
                mask[j], new_dim, interpolation=cv2.INTER_AREA).astype('uint8')
            img_array.append(new_img)
            mask_array.append(new_mask)
    print("Augmentation done")
    return img_array, mask_array


def load_slices(img_size, imgs, masks, n_images):
    print("\nStarting augmentation...")
    img_array = []
    mask_array = []
    for i in range(n_images):
        img = unpack(imgs[i])
        mask = unpack(masks[i])
        start_idx = int(img.shape[2] * 0.2)
        stop_idx = int(img.shape[2] * 0.8)
        new_dim = (img_size, img_size)
        for j in range(start_idx, stop_idx):
            new_img = cv2.resize(img[..., j], new_dim).astype('uint8')
            new_mask = cv2.resize(mask[..., j], new_dim).astype('uint8')
            img_array.append(new_img)
            mask_array.append(new_mask)
    print("Augmentation done")
    return img_array, mask_array
